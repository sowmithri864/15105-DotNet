﻿using System;
using System.Linq;

namespace EFCFMastek
{
    class Program
    {
        private static void SeedDataBase()
        {
            EFCFContext db = new EFCFContext();
            Category category1 = new Category()
            {
                CategoryId = 1,
                CategoryName = "Electronics"
            };
            db.Categories.Add(category1);
            db.SaveChanges();

            Product product1 = new Product()
            {
                ProductId = 101,
                ProductName = "Laptop",
                Category = category1,
                price = 100000
            };
            db.products.Add(product1);
            db.SaveChanges();
        }
        static void Main(string[] args)
        {
            //SeedDataBase();

            EFCFContext db = new EFCFContext();

            Console.WriteLine("--------Category Table Data-----\n ");

            var query1 = db.Categories.ToList();

            foreach(var item in query1)
            {
                Console.WriteLine(item.CategoryId + " " + item.CategoryName);
            }

            Console.WriteLine("\n-----Product Table Data----\n ");

            var query2 = from p in db.products select p;

            foreach(var item in query2)
            {
                Console.WriteLine(item.ProductId + " " + item.ProductName + " " + item.price + " " + item.Category.CategoryId);
            }

            
           
        }
    }
}
