﻿[
    { "firstName": "Sowmithri", "lastName": "Chirala" },
    { "firstName": "Sachin", "lastName": "Tendulkar" },
    { "firstName": "Rahul", "lastName": "Dravid" }
]