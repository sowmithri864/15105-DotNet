﻿using MVCRadioAssignment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCRadioAssignment.ViewModels
{
    public class RadioDemoViewModel
    {
        public string Country { get; set; }
        public List<string> CountryList { get; set; }
        public List<Employee> Employees { get; set; }
        
    }
}
